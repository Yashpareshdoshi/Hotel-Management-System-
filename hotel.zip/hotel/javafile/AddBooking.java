import java.sql.*;
import javax.swing.*;

public class AddBooking extends JFrame {
    JComboBox<String> customerBox, roomBox, dayBox;
    JButton bookButton;

    public AddBooking() {
        setTitle("Confirm booking");
        setLayout(null);
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ComboBoxes
        customerBox = new JComboBox<>();
        roomBox = new JComboBox<>();
        dayBox = new JComboBox<>();

        // Button
        bookButton = new JButton("Book Room");

        // Add to Frame
        add(new JLabel("Select Customer:"));
        add(customerBox);
        add(new JLabel("Select Room:"));
        add(roomBox);
        add(new JLabel("Select Day:"));
        add(dayBox);
        add(new JLabel(""));
        add(bookButton);

        loadComboData();
        bookButton.addActionListener(e -> bookRoom());

        setVisible(true);
    }

    // Load foreign key data into combo boxes
    private void loadComboData() {
        try (Connection con = DBConnection.getConnection()) {
            // Load customers
            PreparedStatement pst = con.prepareStatement("SELECT id, name FROM customers");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                customerBox.addItem(rs.getInt("id") + " - " + rs.getString("name"));
            }

            // Load rooms
            pst = con.prepareStatement("SELECT id, type FROM rooms");
            rs = pst.executeQuery();
            while (rs.next()) {
                roomBox.addItem(rs.getInt("id") + " - " + rs.getString("type"));
            }

            // Load bookrooms (days)
            pst = con.prepareStatement("SELECT day, names FROM bookrooms");
            rs = pst.executeQuery();
            while (rs.next()) {
                dayBox.addItem(rs.getInt("day") + " - " + rs.getString("names"));
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
        }
    }

    // Handle Booking Button
    private void bookRoom() {
        try (Connection con = DBConnection.getConnection()) {
            int customerId = Integer.parseInt(((String) customerBox.getSelectedItem()).split(" - ")[0]);
            int roomId = Integer.parseInt(((String) roomBox.getSelectedItem()).split(" - ")[0]);
            int dayId = Integer.parseInt(((String) dayBox.getSelectedItem()).split(" - ")[0]);

            String sql = "INSERT INTO bookings (customer_id, room_id, day_book) VALUES (?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, customerId);
            pst.setInt(2, roomId);
            pst.setInt(3, dayId);

            int rows = pst.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Booking Successful!");
            } else {
                JOptionPane.showMessageDialog(this, "Booking Failed!");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error inserting booking: " + ex.getMessage());
        }
    }

  
    // MAIN METHOD FOR TEST
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AddBooking());
    }
}