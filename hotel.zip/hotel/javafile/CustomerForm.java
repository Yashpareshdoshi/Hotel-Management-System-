import java.awt.*;
import java.sql.*; 
import javax.swing.*;

public class CustomerForm extends JFrame {
      JTextField nameField, phoneField, emailField,idField;
      JButton submitBtn;    
       Image backgroundImg;
public CustomerForm() {
    setTitle("Add Customer");
    setSize(1000, 1000);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    // Load background image
    backgroundImg = new ImageIcon(getClass().getResource("/icons/customer1.png")).getImage(); // Replace with actual path

    JPanel backgroundPanel = new JPanel() {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImg, 0, 0, getWidth(), getHeight(), this);
        }
    };
    backgroundPanel.setOpaque(false);
    backgroundPanel.setLayout(new GridBagLayout());

    Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
    Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(8, 10, 8, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel idLabel = new JLabel("ID:");
    idLabel.setFont(new Font("Arial", Font.BOLD, 40)); 

     idLabel.setForeground(Color.black);
    idField = new JTextField(20);
    idField.setFont(fieldFont);

    JLabel nameLabel = new JLabel("Name:");
    nameLabel.setFont(new Font("Arial", Font.BOLD, 40)); 
   
     nameLabel.setForeground(Color.black);
    nameField = new JTextField(20);
    nameField.setFont(fieldFont);

    JLabel phoneLabel = new JLabel("Phone:");
phoneLabel.setFont(new Font("Arial", Font.BOLD, 40)); 
   
     phoneLabel.setForeground(Color.black);
    phoneField = new JTextField(20);
    phoneField.setFont(fieldFont);

    JLabel emailLabel = new JLabel("Email:");
emailLabel.setFont(new Font("arial", Font.BOLD, 40)); 
     emailLabel.setForeground(Color.black);
    emailField = new JTextField(20);
    emailField.setFont(fieldFont);

    submitBtn = new JButton("Submit");
    submitBtn.setFont(labelFont);
    submitBtn.setBackground(new Color(0, 102, 204));
    submitBtn.setForeground(Color.WHITE);
    submitBtn.setFocusPainted(false);
    submitBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

    submitBtn.addActionListener(e -> saveCustomer());

    int y = 0;
gbc.gridx = 0; gbc.gridy = y; backgroundPanel.add(idLabel, gbc);
gbc.gridx = 1; backgroundPanel.add(idField, gbc);

gbc.gridy = ++y; gbc.gridx = 0; backgroundPanel.add(nameLabel, gbc);
gbc.gridx = 1; backgroundPanel.add(nameField, gbc);

gbc.gridy = ++y; gbc.gridx = 0; backgroundPanel.add(phoneLabel, gbc);
gbc.gridx = 1; backgroundPanel.add(phoneField, gbc);

gbc.gridy = ++y; gbc.gridx = 0; backgroundPanel.add(emailLabel, gbc);
gbc.gridx = 1; backgroundPanel.add(emailField, gbc);

gbc.gridy = ++y; gbc.gridx = 0; gbc.gridwidth = 2;
backgroundPanel.add(submitBtn, gbc);

    setContentPane(backgroundPanel);
    setVisible(true);
}

private void saveCustomer() {
    try (Connection con = DBConnection.getConnection()) {
        String sql = "INSERT INTO customers (id,name, phone, email) VALUES (?,?, ?, ?)";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, idField.getText());
        stmt.setString(2, nameField.getText());
        stmt.setString(3, phoneField.getText());
        stmt.setString(4, emailField.getText());
        stmt.executeUpdate();
        JOptionPane.showMessageDialog(this, "Customer added!");
    } catch (Exception ex) {
       
        JOptionPane.showMessageDialog(this, "Error adding customer.");
    }
}

public static void main(String[] args) {
    SwingUtilities.invokeLater(CustomerForm::new);
}
}