import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    
    private static final String URL = "jdbc:mysql://localhost:3306/hotel_db";
    private static final String USER = "yash"; // use your MySQL username
    private static final String PASSWORD = "Kajal@9977"; // use your MySQL password

    public static Connection getConnection() {
        Connection conn = null;
        try {
            // Load the MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Create the connection
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to database successfully.");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Connection failed.");
            e.printStackTrace();
        }
        return conn;
    }

    // For testing the connection
    public static void main(String[] args) {
        getConnection();
    }
}