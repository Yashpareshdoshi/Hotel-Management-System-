import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class BookRoom extends JFrame {
    JTextField roomField, customerField, nameField, daysField;
    JButton bookButton;
    Image backgroundImg;

    public BookRoom() {
        setTitle("Book Room");
       setSize(1000, 1000);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Load background image
        backgroundImg = new ImageIcon(getClass().getResource("/icons/bookroom1.png")).getImage(); // Make sure this file is in your project folder

        JPanel backgroundPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImg, 0, 0, getWidth(), getHeight(), this);
            }
        };
        backgroundPanel.setOpaque(false);
        backgroundPanel.setLayout(new GridBagLayout());
        

        Font font = new Font("Segoe UI", Font.BOLD, 14);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel roomLabel = new JLabel("Room No:");
        roomLabel.setForeground(Color.black);
        roomLabel.setFont(font);
        roomField = new JTextField(15);

        JLabel customerLabel = new JLabel("Customer ID:");
        customerLabel.setFont(font);
        customerLabel.setForeground(Color.black);
        customerField = new JTextField(15);

        JLabel nameLabel = new JLabel("Customer Name:");
        nameLabel.setFont(font);
        nameLabel.setForeground(Color.black);
        nameField = new JTextField(15);

        JLabel daysLabel = new JLabel("Days:");
        daysLabel.setFont(font);
        daysLabel.setForeground(Color.black);
        daysField = new JTextField(15);

        // Button with custom background
        bookButton = new JButton("Book");
        bookButton.setFont(font);
        bookButton.setForeground(Color.WHITE);
        bookButton.setContentAreaFilled(false);
        bookButton.setOpaque(true);
        bookButton.setBackground(new Color(0, 102, 204));
        bookButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        bookButton.addActionListener(e -> book_Room());

        int y = 0;
        for (Component comp : new Component[]{roomLabel, roomField, customerLabel, customerField, nameLabel, nameField, daysLabel, daysField, bookButton}) {
            gbc.gridx = 0;
            gbc.gridy = y++;
            gbc.gridwidth = comp instanceof JButton ? 2 : 1;
            backgroundPanel.add(comp, gbc);
        }

        setContentPane(backgroundPanel);
        setVisible(true);
    }

    private void book_Room() {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO bookrooms (id, customer_id, names, day) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, Integer.parseInt(roomField.getText()));
            pst.setInt(2, Integer.parseInt(customerField.getText()));
            pst.setString(3, nameField.getText());
            pst.setInt(4, Integer.parseInt(daysField.getText()));
            pst.executeUpdate();

            String updateRoom = "UPDATE rooms SET status = 'Booked' WHERE id = ?";
            pst = con.prepareStatement(updateRoom);
            pst.setInt(1, Integer.parseInt(roomField.getText()));
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Room booked successfully.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BookRoom::new);
    }
}

