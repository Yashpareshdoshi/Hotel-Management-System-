import java.awt.*;
 import java.sql.*;
  import javax.swing.*;

public class Checkout extends JFrame { 
    JTextField roomField; 
    JButton checkoutButton; 
    Image backgroundImg;
public Checkout() {
    setTitle("Room Checkout");
     setSize(1000, 1000);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    // Load background image
    backgroundImg = new ImageIcon(getClass().getResource("/icons/checkout1.png")).getImage(); // Replace with your image path

    JPanel backgroundPanel = new JPanel() {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImg, 0, 0, getWidth(), getHeight(), this);
        }
    };
     backgroundPanel.setOpaque(false);
    backgroundPanel.setLayout(new GridBagLayout());

    Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
    Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;

    JLabel roomLabel = new JLabel("Room No:");
    roomLabel.setFont(labelFont);
     roomLabel.setForeground(Color.black);
    roomField = new JTextField(15);
    roomField.setFont(fieldFont);

    checkoutButton = new JButton("Checkout");
    checkoutButton.setFont(labelFont);
    checkoutButton.setBackground(new Color(220, 53, 69)); // Bootstrap "danger" red
    checkoutButton.setForeground(Color.WHITE);
    checkoutButton.setFocusPainted(false);
    checkoutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

    checkoutButton.addActionListener(e -> checkoutRoom());

    gbc.gridx = 0; gbc.gridy = 0;
    backgroundPanel.add(roomLabel, gbc);
    gbc.gridx = 1;
    backgroundPanel.add(roomField, gbc);

    gbc.gridy = 1; gbc.gridx = 0; gbc.gridwidth = 2;
    backgroundPanel.add(checkoutButton, gbc);

    setContentPane(backgroundPanel);
    setVisible(true);
}

private void checkoutRoom() {
    try (Connection con = DBConnection.getConnection()) {
        String deleteBooking = "DELETE FROM bookrooms WHERE id = ?";
        PreparedStatement pst = con.prepareStatement(deleteBooking);
        pst.setString(1, roomField.getText());
        pst.executeUpdate();

        String updateRoom = "UPDATE rooms SET status = 'Available' WHERE id = ?";
        pst = con.prepareStatement(updateRoom);
        pst.setString(1, roomField.getText());
        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Room checked out successfully.");
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    }
}

public static void main(String[] args) {
    SwingUtilities.invokeLater(Checkout::new);
}
}
