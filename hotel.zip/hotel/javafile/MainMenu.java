import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import javax.swing.*;

public class MainMenu {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Hotel Management System");

        // Set dark gray background
        frame.getContentPane().setBackground(Color.DARK_GRAY);
        frame.setLayout(new BorderLayout());

        // --- Logo Panel at Top Left ---
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        logoPanel.setBackground(Color.DARK_GRAY);
        JLabel labelhotel = new JLabel("4cs hotel");
        
        labelhotel.setFont(new Font("Times New Roman", Font.PLAIN, 60));
        labelhotel.setForeground(Color.WHITE);
        logoPanel.add(labelhotel);


        URL logoPath = MainMenu.class.getResource("/icons/hotel_logo.png");
        if (logoPath != null) {
    ImageIcon originalLogo = new ImageIcon(logoPath);
    Image image = originalLogo.getImage();
    Image scaledImage = image.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
    ImageIcon resizedLogo = new ImageIcon(scaledImage);
    JLabel logoLabel = new JLabel(resizedLogo);
    logoPanel.add(logoLabel);
        } else {
            System.err.println("Logo not found at /icons/hotel_logo.png");
        }

        frame.add(logoPanel, BorderLayout.NORTH);

        // --- Button Panel in Center ---
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(6, 1, 10, 10)); // 6 rows, 1 column
        buttonPanel.setBackground(Color.DARK_GRAY);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40)); // Padding to start lower

        // Create buttons
        JButton customerBtn = createButton("Add Customer", new Color(100, 149, 237), "/icons/customer.png");
        JButton roomBtn = createButton("Add Room", new Color(60, 179, 113), "/icons/addroom.png");
        JButton bookBtn = createButton("Book Room", new Color(255, 165, 0), "/icons/bookroom.png");
        JButton viewBtn = createButton("View Bookings", new Color(255, 69, 0), "/icons/view.png");
        JButton checkoutBtn = createButton("Check Out", new Color(220, 20, 60), "/icons/checkout.png");

        // Add buttons
        buttonPanel.add(customerBtn);
        buttonPanel.add(roomBtn);
        buttonPanel.add(bookBtn);
        buttonPanel.add(viewBtn);
        buttonPanel.add(checkoutBtn);

        frame.add(buttonPanel, BorderLayout.CENTER);

        // Frame properties
        frame.setSize(450, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // Button functionality
        customerBtn.addActionListener(e -> new CustomerForm());
        roomBtn.addActionListener(e -> new AddRoom());
        bookBtn.addActionListener(e -> new BookRoom());
        viewBtn.addActionListener(e -> new ViewBooking());
        checkoutBtn.addActionListener(e -> new Checkout());
    }

    private static JButton createButton(String text, Color color, String iconPath) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 32));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        button.setHorizontalTextPosition(SwingConstants.RIGHT);

        URL iconURL = MainMenu.class.getResource(iconPath);
        if (iconURL != null) {
            ImageIcon originalIcon = new ImageIcon(iconURL);
            Image resized = originalIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
            button.setIcon(new ImageIcon(resized));
        } else {
            System.err.println("Icon not found: " + iconPath);
        }

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });

        return button;
    }
}

