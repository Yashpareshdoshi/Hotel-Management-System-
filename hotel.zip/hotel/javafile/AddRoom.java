import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class AddRoom extends JFrame {
    JTextField roomField, typeField, priceField;
    JButton addButton;
    Image backgroundImg;

    public AddRoom() {
        setTitle("Add Room");
        setSize(1000, 1000);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Load background image
        backgroundImg = new ImageIcon(getClass().getResource("/icons/addroom1.png")).getImage(); // Use a real path or make sure it's in the project folder

        JPanel backgroundPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImg, 0, 0, getWidth(), getHeight(), this);
            }
        };
         backgroundPanel.setOpaque(false);
        backgroundPanel.setLayout(new GridBagLayout());
       

        Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // UI Components
        JLabel roomLabel = new JLabel("Room No:");
        roomLabel.setFont(labelFont);
         roomLabel.setForeground(Color.black);
        roomField = new JTextField(15);
        roomField.setFont(fieldFont);

        JLabel typeLabel = new JLabel("Type:");
        typeLabel.setFont(labelFont);
         typeLabel.setForeground(Color.black);
        typeField = new JTextField(15);
        typeField.setFont(fieldFont);

        JLabel priceLabel = new JLabel("Price:");
        priceLabel.setFont(labelFont);
         priceLabel.setForeground(Color.black);
        priceField = new JTextField(15);
        priceField.setFont(fieldFont);

        addButton = new JButton("Add Room");
        addButton.setFont(labelFont);
        addButton.setBackground(new Color(0, 153, 76));
        addButton.setForeground(Color.black);
        addButton.setFocusPainted(false);
        addButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        addButton.addActionListener(e -> addRoomToDatabase());

        // Add components to panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        backgroundPanel.add(roomLabel, gbc);
        gbc.gridx = 1;
        backgroundPanel.add(roomField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        backgroundPanel.add(typeLabel, gbc);
        gbc.gridx = 1;
        backgroundPanel.add(typeField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        backgroundPanel.add(priceLabel, gbc);
        gbc.gridx = 1;
        backgroundPanel.add(priceField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        backgroundPanel.add(addButton, gbc);

        setContentPane(backgroundPanel);
        setVisible(true);
    }

    private void addRoomToDatabase() {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO rooms (id, type, price, status) VALUES (?, ?, ?, 'Available')";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, roomField.getText());
            pst.setString(2, typeField.getText());
            pst.setString(3, priceField.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Room added successfully.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AddRoom::new);
    }
}

