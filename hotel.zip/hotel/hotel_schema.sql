-- Active: 1744952902276@@127.0.0.1@3306
CREATE DATABASE IF NOT EXISTS hotel_db;
USE hotel_db;

CREATE TABLE IF NOT EXISTS customers (
    id INT PRIMARY KEY ,
    name VARCHAR(100),
    phone VARCHAR(15),
    email VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS rooms (
    id INT PRIMARY KEY,
    type VARCHAR(50),
    status VARCHAR(20),
    price DOUBLE
);


create table bookrooms(
    id int ,
     customer_id INT,
     Foreign key (id) REFERENCES rooms(id),
   FOREIGN KEY (customer_id) REFERENCES customers(id),
    names varchar(20),
    day int 
);
